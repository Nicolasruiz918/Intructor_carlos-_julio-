package com.sena.crudbasic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudbasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
