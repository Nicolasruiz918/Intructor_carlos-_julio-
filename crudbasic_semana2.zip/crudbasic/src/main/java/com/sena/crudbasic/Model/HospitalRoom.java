package com.sena.crudbasic.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.util.List;

@Entity
@Table(name = "hospital_room")
public class HospitalRoom {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_room")
    private int id;

    @Column(name = "room_number", unique = true, length = 20)
    private String roomNumber;

    @Column(name = "type", length = 50)
    private String type;

    @Column(name = "occupied")
    private boolean occupied = false;

    @OneToMany(mappedBy = "room")
    private List<Admission> admissions;

    public HospitalRoom() {
    }

    public int  getId() {
         return id; 
        }

    public void setId(int id) {
         this.id = id; 
        }

    public String getRoomNumber() {
         return roomNumber; 
        }
    
        public void setRoomNumber(String roomNumber) {
             this.roomNumber = roomNumber; 
            }

    public String getType() {
         return type;
         }
    
         public void setType(String type) { 
            this.type = type; 
        }

    public boolean isOccupied() { 
        return occupied; 
    }

    public void setOccupied(boolean occupied) { 
        this.occupied = occupied;
     }

    public List<Admission> getAdmissions() { 
        return admissions; 
    }

    public void setAdmissions(List<Admission> admissions) { 
        this.admissions = admissions;
     }
}