package com.sena.crudbasic.dto;

import java.time.LocalDateTime;

public class MedicalRecordDto {

    private int id;
    private LocalDateTime recordDate;
    private String symptoms;
    private String observations;
    private String patientName;
    private String doctorName;

    public MedicalRecordDto(int id, LocalDateTime recordDate, String symptoms, String observations, String patientName, String doctorName) {
        this.id = id;
        this.recordDate = recordDate;
        this.symptoms = symptoms;
        this.observations = observations;
        this.patientName = patientName;
        this.doctorName = doctorName;
    }

    public int  getId() {
         return id;
         }

    public void setId(int id) {
         this.id = id;
        }

    public LocalDateTime getRecordDate() {
         return recordDate;
         }
    public void setRecordDate(LocalDateTime recordDate) {
         this.recordDate = recordDate;
         }

    public String getSymptoms() {
         return symptoms;
         }
         public void setSymptoms(String symptoms) { 
            this.symptoms = symptoms; 
        }

    public String getObservations() {
         return observations;
         }

    public void setObservations(String observations) { 
        this.observations = observations;
     }

    public String getPatientName() {
         return patientName; 
        }

    public void setPatientName(String patientName) { 
        this.patientName = patientName;
     }
    public String getDoctorName() { 
        return doctorName;
     }
    public void setDoctorName(String doctorName) {
         this.doctorName = doctorName; 
        }
}