package com.sena.crudbasic.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sena.crudbasic.Model.Admission;
import com.sena.crudbasic.dto.AdmissionDto;
import com.sena.crudbasic.repository.AdmissionRepository;
import com.sena.crudbasic.service.AdmissionService;

@Service
public class AdmissionServiceImpl implements AdmissionService {

    @Autowired
    private AdmissionRepository repo;

    @Override
    public List<Admission> findAll(){
        return this.repo.findAll();
    }

    @Override
    public Admission findById(int id){
        return repo.findById(id).orElse(null);
    }

    @Override
    public List<Admission> findActiveAdmissions(){
        return repo.findActiveAdmissions();
    }

    public Admission dtoToModel(AdmissionDto admissionDto){
        Admission a = new Admission();
        a.setId(admissionDto.getId());
        a.setAdmissionDate(admissionDto.getAdmissionDate());
        a.setDischargeDate(admissionDto.getDischargeDate());
        return a;
    }

    @Override
    public String save(AdmissionDto admissionDto){
        Admission admission = dtoToModel(admissionDto);
        repo.save(admission);
        return "Ingreso guardado exitosamente";
    }

    @Override
    public String delete(int id){
        repo.deleteById(id);
        return "Se eliminó";
    }
}