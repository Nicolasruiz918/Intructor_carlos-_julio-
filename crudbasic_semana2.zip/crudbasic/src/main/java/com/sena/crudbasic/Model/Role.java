package com.sena.crudbasic.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.util.List;

@Entity
@Table(name = "role")
public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_role")
    private int id;

    @Column(name = "role_name", unique = true, nullable = false, length = 50)
    private String roleName;

    @OneToMany(mappedBy = "role")
    private List<UserRole> userRoles;

    public Role() {}

    public int getId() { 
        return id; 
    }
    public void setId(int id) { 
        this.id = id;
     }

    public String getRoleName() { 
        return roleName; 
    }
    
    public void setRoleName(String roleName) { 
        this.roleName = roleName; 
    }

    public List<UserRole> getUserRoles() { 
        return userRoles; 
    }
    
    public void setUserRoles(List<UserRole> userRoles) { 
        this.userRoles = userRoles; 
    }
}