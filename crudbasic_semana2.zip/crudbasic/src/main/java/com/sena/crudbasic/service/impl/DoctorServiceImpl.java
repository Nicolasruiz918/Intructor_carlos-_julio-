package com.sena.crudbasic.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sena.crudbasic.Model.Doctor;
import com.sena.crudbasic.dto.DoctorDto;
import com.sena.crudbasic.repository.DoctorRepository;
import com.sena.crudbasic.service.DoctorService;

@Service
public class DoctorServiceImpl implements DoctorService {

    @Autowired
    private DoctorRepository repo;

    @Override
    public List<Doctor> findAll(){
        return this.repo.findAll();
    }

    @Override
    public Doctor findById(int id){
        return repo.findById(id).orElse(null);
    }

    @Override
    public List<Doctor> filterBySpecialty(String specialty){
        return repo.filterBySpecialty(specialty);
    }

    public Doctor dtoToModel(DoctorDto doctorDto){
        Doctor d = new Doctor();
        d.setId(doctorDto.getId());
        d.setLicenseNumber(doctorDto.getLicenseNumber());
        d.setFullName(doctorDto.getFullName());
        d.setPhone(doctorDto.getPhone());
        return d;
    }

    @Override
    public String save(DoctorDto doctorDto){
        Doctor doctor = dtoToModel(doctorDto);
        repo.save(doctor);
        return "Doctor guardado exitosamente";
    }

    @Override
    public String delete(int id){
        repo.deleteById(id);
        return null;
    }
}