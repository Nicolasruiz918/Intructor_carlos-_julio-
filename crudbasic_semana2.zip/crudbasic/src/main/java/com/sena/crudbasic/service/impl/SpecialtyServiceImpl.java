package com.sena.crudbasic.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sena.crudbasic.Model.Specialty;
import com.sena.crudbasic.dto.SpecialtyDto;
import com.sena.crudbasic.repository.SpecialtyRepository;
import com.sena.crudbasic.service.SpecialtyService;

@Service
public class SpecialtyServiceImpl implements SpecialtyService {

    @Autowired
    private SpecialtyRepository repo;

    @Override
    public List<Specialty> findAll(){
        return this.repo.findAll();
    }

    @Override
    public Specialty findById(int id){
        return repo.findById(id).orElse(null);
    }

    @Override
    public List<Specialty> filterByName(String name){
        return repo.filterByName(name);
    }

    public Specialty dtoToModel(SpecialtyDto specialtyDto){
        Specialty s = new Specialty();
        s.setId(specialtyDto.getId());
        s.setName(specialtyDto.getName());
        return s;
    }

    @Override
    public String save(SpecialtyDto specialtyDto){
        Specialty specialty = dtoToModel(specialtyDto);
        repo.save(specialty);
        return "Especialidad guardada exitosamente";
    }

    @Override
    public String delete(int id){
        repo.deleteById(id);
        return "Se eliminó";
    }
}