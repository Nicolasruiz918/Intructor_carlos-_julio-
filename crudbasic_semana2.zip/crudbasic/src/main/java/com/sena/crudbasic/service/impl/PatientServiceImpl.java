package com.sena.crudbasic.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sena.crudbasic.Model.Patient;
import com.sena.crudbasic.dto.PatientDto;
import com.sena.crudbasic.repository.PatientRepository;
import com.sena.crudbasic.service.PatientService;

@Service
public class PatientServiceImpl implements PatientService {

    @Autowired
    private PatientRepository repo;

    @Override
    public List<Patient> findAll() {
        return repo.findAll();
    }

    @Override
    public Patient findById(int id) {
        return repo.findById(id).orElse(null);
    }

    @Override
    public List<Patient> filterByDni(String dni) {
        return repo.filterByDni(dni);
    }

    @Override
    public List<Patient> filterByFullName(String fullName) {
        return repo.filterByFullName(fullName);
    }

    public Patient dtoToModel(PatientDto dto) {
        Patient p = new Patient();
        p.setId(dto.getId());
        p.setDni(dto.getDni());
        p.setFullName(dto.getFullName());
        p.setBirthDate(dto.getBirthDate());
        p.setPhone(dto.getPhone());
        p.setBloodType(dto.getBloodType());
        return p;
    }

    @Override
    public String save(PatientDto dto) {
        repo.save(dtoToModel(dto));
        return "Paciente guardado exitosamente";
    }

    @Override
    public String delete(int id) {
        repo.deleteById(id);
        return "Paciente eliminado";
    }
    }