package com.sena.crudbasic.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sena.crudbasic.Model.MedicalRecord;
import com.sena.crudbasic.dto.MedicalRecordDto;
import com.sena.crudbasic.repository.MedicalRecordRepository;
import com.sena.crudbasic.service.MedicalRecordService;

@Service
public class MedicalRecordServiceImpl implements MedicalRecordService {

    @Autowired
    private MedicalRecordRepository repo;

    @Override
    public List<MedicalRecord> findAll(){
        return this.repo.findAll();
    }

    @Override
    public MedicalRecord findById(int id){
        return repo.findById(id).orElse(null);
    }

    @Override
    public List<MedicalRecord> filterByPatientName(String patientName){
        return repo.filterByPatientName(patientName);
    }

    public MedicalRecord dtoToModel(MedicalRecordDto recordDto){
        MedicalRecord m = new MedicalRecord();
        m.setId(recordDto.getId());
        m.setRecordDate(recordDto.getRecordDate());
        m.setSymptoms(recordDto.getSymptoms());
        m.setObservations(recordDto.getObservations());
        return m;
    }

    @Override
    public String save(MedicalRecordDto recordDto){
        MedicalRecord record = dtoToModel(recordDto);
        repo.save(record);
        return "Historia clínica guardada exitosamente";
    }

    @Override
    public String delete(int id){
        repo.deleteById(id);
        return "Se eliminó";
    }
}