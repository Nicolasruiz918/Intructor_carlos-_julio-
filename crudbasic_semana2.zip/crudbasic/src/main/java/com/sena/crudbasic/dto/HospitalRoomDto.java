package com.sena.crudbasic.dto;


public class HospitalRoomDto {

    private int  id;
    private String roomNumber;
    private String type;
    private boolean occupied;

    public HospitalRoomDto(int id, String roomNumber, String type, boolean occupied) {
        this.id = id;
        this.roomNumber = roomNumber;
        this.type = type;
        this.occupied = occupied;
    }

    public int getId() {
         return id;
         }
    
    public void setId(int id) { 
        this.id = id;
     }
    public String getRoomNumber() { 
        return roomNumber;
     }
    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
     }

    public String getType() {
         return type; 

    }

    public void setType(String type) { 
        this.type = type; 
    }

    public boolean isOccupied() {
         return occupied;
         }

    public void setOccupied(boolean occupied) { 
        this.occupied = occupied; 
    }
}