package com.sena.crudbasic.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "diagnosis")
public class Diagnosis {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_diagnosis")
    private int id;

    @Column(name = "code_cie10", length = 10)
    private String code;

    @Column(name = "description", length = 500)
    private String description;

    @ManyToOne
    @JoinColumn(name = "id_record")
    private MedicalRecord medicalRecord;

    public Diagnosis() {
    }

    public int  getId() {
         return id;
         }

    public void setId(int  id) {
         this.id = id;
         }

    public String getCode() {
         return code; 
        }

    public void setCode(String code) { 
        this.code = code; 
    }

    public String getDescription() { 
        return description; 
    }

    public void setDescription(String description) {
         this.description = description;
         
        }

    public MedicalRecord getMedicalRecord() {
         return medicalRecord;
         }

    public void setMedicalRecord(MedicalRecord medicalRecord) {
         this.medicalRecord = medicalRecord; 
        }
}