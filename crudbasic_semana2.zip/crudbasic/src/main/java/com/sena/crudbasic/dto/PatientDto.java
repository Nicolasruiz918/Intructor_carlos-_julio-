package com.sena.crudbasic.dto;

import java.time.LocalDate;

public class PatientDto {

    private int id;
    private String dni;
    private String fullName;
    private LocalDate birthDate;
    private String phone;
    private String bloodType;

    public PatientDto(int id, String dni, String fullName, LocalDate birthDate, String phone, String bloodType) {
        this.id = id;
        this.dni = dni;
        this.fullName = fullName;
        this.birthDate = birthDate;
        this.phone = phone;
        this.bloodType = bloodType;
    }


    public int  getId() { 
		return id; 
	}
    
	public void setId(int  id) {
		 this.id = id; 

	}

    public String getDni() {
		 return dni; 

	}

    public void setDni(String dni) {
		 this.dni = dni; 
		}

    public String getFullName() { 
		return fullName; 
	}
    
	public void setFullName(String fullName) { 
		this.fullName = fullName; 
	}
	

    public LocalDate getBirthDate() {
		return birthDate; }
    public void setBirthDate(LocalDate birthDate) { 
		this.birthDate = birthDate; 
	}

    public String getPhone() {
		 return phone;
		 }
    public void setPhone(String phone) {
		 this.phone = phone; 
		}

    public String getBloodType() { 
		return bloodType; 
	}
    public void setBloodType(String bloodType) {
		 this.bloodType = bloodType; 
		}
}