package com.sena.crudbasic.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sena.crudbasic.Model.Appointment;
import com.sena.crudbasic.dto.AppointmentDto;
import com.sena.crudbasic.repository.AppointmentRepository;
import com.sena.crudbasic.service.AppointmentService;

@Service
public class AppointmentServiceImpl implements AppointmentService {

    @Autowired
    private AppointmentRepository repo;

    @Override
    public List<Appointment> findAll() {
        return repo.findAll();
    }

    @Override
    public Appointment findById(int id) {
        return repo.findById(id).orElse(null);
    }

    @Override
    public List<Appointment> filterByStatus(String status) {
        return repo.filterByStatus(status);
    }

    public Appointment dtoToModel(AppointmentDto dto) {
        Appointment a = new Appointment();
        a.setId(dto.getId());
        a.setAppointmentDate(dto.getAppointmentDate());
        a.setReason(dto.getReason());
        a.setStatus(dto.getStatus() != null ? dto.getStatus() : "PROGRAMADA");
        return a;
    }

    @Override
    public String save(AppointmentDto dto) {
        repo.save(dtoToModel(dto));
        return "Cita guardada exitosamente";
    }

    @Override
    public String delete(int id) {
        repo.deleteById(id);
        return "Cita eliminada";
    }
} 