package com.sena.crudbasic.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.util.List;

@Entity
@Table(name = "doctor")
public class Doctor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_doctor")
    private int id;

    @Column(name = "license_number")
    private String licenseNumber;

    @Column(name = "full_name")
    private String fullName;

    @Column(name = "phone")
    private String phone;

    @ManyToOne
    @JoinColumn(name = "id_specialty")
    private Specialty specialty;

    @OneToMany(mappedBy = "doctor")
    private List<Appointment> appointments;

    @OneToMany(mappedBy = "doctor")
    private List<MedicalRecord> medicalRecords;

    public Doctor() {
    }

    public int getId() { 
        return id;
     }

    public void setId( int id) {
         this.id = id; 
        }

    public String getLicenseNumber() { 
        return licenseNumber; 
    }
    public void setLicenseNumber(String licenseNumber) {
         this.licenseNumber = licenseNumber; 
        }

    public String getFullName() {
         return fullName; 
        }

    public void setFullName(String fullName) { 
        this.fullName = fullName;
     }

    public String getPhone() { 
        return phone; 
    }
    public void setPhone(String phone) { 
        this.phone = phone; 
    }

    public Specialty getSpecialty() { 
        return specialty;
     }
    
     public void setSpecialty(Specialty specialty) {
         this.specialty = specialty;
         }

    public List<Appointment> getAppointments() { 
        return appointments;
     }

    public void setAppointments(List<Appointment> appointments) { 
        this.appointments = appointments;
     }

    public List<MedicalRecord> getMedicalRecords() { 
        return medicalRecords; 
    }
    
    public void setMedicalRecords(List<MedicalRecord> medicalRecords) {
         this.medicalRecords = medicalRecords; 
        }
}