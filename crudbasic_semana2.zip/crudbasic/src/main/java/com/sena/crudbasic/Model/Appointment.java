package com.sena.crudbasic.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

@Entity
@Table(name = "appointment")
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_appointment")
    private int id;                              // ← int como tú quieres

    @Column(name = "appointment_date", nullable = false)
    private LocalDateTime appointmentDate;

    @Column(name = "reason", length = 500)
    private String reason;

    @Column(name = "status", length = 20)
    private String status = "PROGRAMADA";

    @ManyToOne
    @JoinColumn(name = "id_patient")
    private Patient patient;

    @ManyToOne
    @JoinColumn(name = "id_doctor")
    private Doctor doctor;


    public Appointment() {}

    public int getId() { 
        return id; 
    }

    public void setId(int id) { 
        this.id = id;
     }

    public LocalDateTime getAppointmentDate() {
         return appointmentDate; 
        }

    public void setAppointmentDate(LocalDateTime appointmentDate) { 
        this.appointmentDate = appointmentDate;
     }

    public String getReason() {
         return reason; 
        }

    public void setReason(String reason) {
         this.reason = reason;
         }

    public String getStatus() {
         return status; 
        }

    public void setStatus(String status) {
         this.status = status;
         }

    public Patient getPatient() { 
        return patient; 
    }

    public void setPatient(Patient patient) {
         this.patient = patient; 
        }


    public Doctor getDoctor() {
         return doctor; 
        }

    public void setDoctor(Doctor doctor) {
         this.doctor = doctor; 
        }
}