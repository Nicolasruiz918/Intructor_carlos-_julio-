package com.sena.crudbasic.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "medical_record")
public class MedicalRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_record")
    private int  id;

    @Column(name = "record_date")
    private LocalDateTime recordDate = LocalDateTime.now();

    @Column(name = "symptoms", length = 2000)
    private String symptoms;

    @Column(name = "observations", length = 3000)
    private String observations;

    @ManyToOne
    @JoinColumn(name = "id_patient")
    private Patient patient;

    @ManyToOne
    @JoinColumn(name = "id_doctor")
    private Doctor doctor;

    @OneToMany(mappedBy = "medicalRecord")
    private List<Diagnosis> diagnoses;

    public MedicalRecord() {
    }

    public int  getId() {
         return id; 
        }

    public void setId(int id) { 
        this.id = id;
     }

    public LocalDateTime getRecordDate() { 
        return recordDate; 
    }
    public void setRecordDate(LocalDateTime recordDate) { 
        this.recordDate = recordDate; 
    }

    public String getSymptoms() {
         return symptoms; 
        }
    public void setSymptoms(String symptoms) { 
        this.symptoms = symptoms; 
    }

    public String getObservations() { 
        return observations; 
    }

    public void setObservations(String observations) { 
        this.observations = observations;
     }

    public Patient getPatient() { 
        return patient; 
    }

    public void setPatient(Patient patient) { 
        this.patient = patient;
     }

    public Doctor getDoctor() { 
        return doctor; 
    }
    public void setDoctor(Doctor doctor) { 
        this.doctor = doctor; 
    }

    public List<Diagnosis> getDiagnoses() {
         return diagnoses;
         }
    
         public void setDiagnoses(List<Diagnosis> diagnoses) { 
            this.diagnoses = diagnoses;
         }
}