package com.sena.crudbasic.dto;

import java.time.LocalDateTime;

public class AppointmentDto {

    private Integer id;
    private LocalDateTime appointmentDate;
    private String reason;
    private String status;
    
    // ESTOS DOS SON LOS QUE TE FALTABAN Y HACÍAN QUE EXPLOTARA TODO
    private Integer patientId;
    private Integer doctorId;

    // Constructor vacío (necesario para Jackson)
    public AppointmentDto() {}

    // Constructor completo
    public AppointmentDto(Integer id, LocalDateTime appointmentDate, String reason, 
                         String status, Integer patientId, Integer doctorId) {
        this.id = id;
        this.appointmentDate = appointmentDate;
        this.reason = reason;
        this.status = status;
        this.patientId = patientId;
        this.doctorId = doctorId;
    }

    // Getters y Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public LocalDateTime getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(LocalDateTime appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getPatientId() {
        return patientId;
    }

    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public Integer getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(Integer doctorId) {
        this.doctorId = doctorId;
    }
}