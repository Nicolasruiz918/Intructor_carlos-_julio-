package com.sena.crudbasic.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sena.crudbasic.Model.User;
import com.sena.crudbasic.dto.UserDto;
import com.sena.crudbasic.repository.UserRepository;
import com.sena.crudbasic.service.UserService;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository repo;

    @Override
    public List<User> findAll(){
        return this.repo.findAll();
    }

    @Override
    public User findById(int id){
        return repo.findById(id).orElse(null);
    }

    @Override
    public List<User> filterByUsername(String username){
        return repo.filterByUsername(username);
    }

    public User dtoToModel(UserDto userDto){
        User u = new User();
        u.setId(userDto.getId());
        u.setUsername(userDto.getUsername());
        u.setPassword(userDto.getPassword());
        u.setEmail(userDto.getEmail());
        u.setEnabled(userDto.isEnabled());
        return u;
    }

    @Override
    public String save(UserDto userDto){
        User user = dtoToModel(userDto);
        repo.save(user);
        return "Usuario guardado exitosamente";
    }

    @Override
    public String delete(int id){
        repo.deleteById(id);
        return "Se eliminó";
    }
}