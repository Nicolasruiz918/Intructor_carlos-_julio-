package com.sena.crudbasic.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.time.LocalDate;
import java.util.List;
import java.util.function.IntBinaryOperator;

@Entity
@Table(name = "patient")
public class Patient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_patient")
    private int id;

    @Column(name = "dni", nullable = false, unique = true, length = 20)
    private String dni;

    @Column(name = "full_name", nullable = false, length = 100)
    private String fullName;

    @Column(name = "birth_date")
    private LocalDate birthDate;

    @Column(name = "phone", length = 20)
    private String phone;


    @Column(name = "blood_type", length = 5)
    private String bloodType;

    @OneToMany(mappedBy = "patient")
    private List<Appointment> appointments;

    @OneToMany(mappedBy = "patient")
    private List<MedicalRecord> medicalRecords;

    @OneToMany(mappedBy = "patient")
    private List<Admission> admissions;

    public Patient() {}

    
    public int getId()
     { return id; }

    public void setId( int id) { 
        this.id = id;
    }

    public String getDni() {
         return dni;
         }

    public void setDni(String dni) {
         this.dni = dni; 
        }
    public String getFullName() {
         return fullName; 
        }

    public void setFullName(String fullName) {
         this.fullName = fullName;
         }

    public LocalDate getBirthDate() {
         return birthDate;
         }

    public void setBirthDate(LocalDate birthDate) { 
        this.birthDate = birthDate; 
    }

    public String getPhone() { 
        return phone;
     }

    public void setPhone(String phone) {
         this.phone = phone;
         }


    public String getBloodType() { 
        return bloodType; 
    }

    public void setBloodType(String bloodType) {
         this.bloodType = bloodType;
         }

    public List<Appointment> getAppointments() {
         return appointments; 
        }
        
    public void setAppointments(List<Appointment> appointments) { 
        this.appointments = appointments;
     }

    public List<MedicalRecord> getMedicalRecords() { 
        return medicalRecords; 
    }

    public void setMedicalRecords(List<MedicalRecord> medicalRecords) {
         this.medicalRecords = medicalRecords;
         }

    public List<Admission> getAdmissions() {
         return admissions; 
        }

    public void setAdmissions(List<Admission> admissions) {
         this.admissions = admissions; 
        }
    
}