package com.sena.crudbasic.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sena.crudbasic.Model.Diagnosis;
import com.sena.crudbasic.dto.DiagnosisDto;
import com.sena.crudbasic.repository.DiagnosisRepository;
import com.sena.crudbasic.service.DiagnosisService;

@Service
public class DiagnosisServiceImpl implements DiagnosisService {

    @Autowired
    private DiagnosisRepository repo;

    @Override
    public List<Diagnosis> findAll(){
        return this.repo.findAll();
    }

    @Override
    public Diagnosis findById(int id){
        return repo.findById(id).orElse(null);
    }

    @Override
    public List<Diagnosis> filterByCode(String code){
        return repo.filterByCode(code);
    }

    public Diagnosis dtoToModel(DiagnosisDto diagnosisDto){
        Diagnosis d = new Diagnosis();
        d.setId(diagnosisDto.getId());
        d.setCode(diagnosisDto.getCode());
        d.setDescription(diagnosisDto.getDescription());
        return d;
    }

    @Override
    public String save(DiagnosisDto diagnosisDto){
        Diagnosis diagnosis = dtoToModel(diagnosisDto);
        repo.save(diagnosis);
        return "Diagnóstico guardado exitosamente";
    }

    @Override
    public String delete(int id){
        repo.deleteById(id);
        return "Se eliminó";
    }
}