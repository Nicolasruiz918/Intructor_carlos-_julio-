package com.sena.crudbasic.dto;

import java.time.LocalDateTime;

public class AdmissionDto {

    private int id;
    private LocalDateTime admissionDate;
    private LocalDateTime dischargeDate;
    private String patientName;
    private String roomNumber;

    public AdmissionDto(int id, LocalDateTime admissionDate, LocalDateTime dischargeDate, String patientName, String roomNumber) {
        this.id = id;
        this.admissionDate = admissionDate;
        this.dischargeDate = dischargeDate;
        this.patientName = patientName;
        this.roomNumber = roomNumber;
    }

    public int getId() {
         return id; 
        }

    public void setId(int id) {
         this.id = id;
         }

    public LocalDateTime getAdmissionDate() {
         return admissionDate; 
        }

    public void setAdmissionDate(LocalDateTime admissionDate) {
         this.admissionDate = admissionDate;
         }

    public LocalDateTime getDischargeDate() {
         return dischargeDate;
         }

    public void setDischargeDate(LocalDateTime dischargeDate) { 
        this.dischargeDate = dischargeDate;
     }
     
    public String getPatientName() {
         return patientName; 
        }

    public void setPatientName(String patientName) { this.patientName = patientName; }
    public String getRoomNumber() {
         return roomNumber; 
        }

    public void setRoomNumber(String roomNumber) {
         this.roomNumber = roomNumber;
         }
}