package com.sena.crudbasic.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sena.crudbasic.Model.HospitalRoom;
import com.sena.crudbasic.dto.HospitalRoomDto;
import com.sena.crudbasic.repository.HospitalRoomRepository;
import com.sena.crudbasic.service.HospitalRoomService;

@Service
public class HospitalRoomServiceImpl implements HospitalRoomService {

    @Autowired
    private HospitalRoomRepository repo;

    @Override
    public List<HospitalRoom> findAll(){
        return this.repo.findAll();
    }

    @Override
    public HospitalRoom findById(int id){
        return repo.findById(id).orElse(null);
    }

    @Override
    public List<HospitalRoom> findAvailableRooms(){
        return repo.findByOccupiedFalse();
    }

    public HospitalRoom dtoToModel(HospitalRoomDto roomDto){
        HospitalRoom r = new HospitalRoom();
        r.setId(roomDto.getId());
        r.setRoomNumber(roomDto.getRoomNumber());
        r.setType(roomDto.getType());
        r.setOccupied(roomDto.isOccupied());
        return r;
    }

    @Override
    public String save(HospitalRoomDto roomDto){
        HospitalRoom room = dtoToModel(roomDto);
        repo.save(room);
        return "Habitación guardada exitosamente";
    }

    @Override
    public String delete(int id){
        repo.deleteById(id);
        return "Se eliminó";
    }
}