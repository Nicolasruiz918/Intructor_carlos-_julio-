package com.sena.crudbasic.dto;

public class DoctorDto {

    private int  id;
    private String licenseNumber;
    private String fullName;
    private String phone;
    private String specialtyName;

    public DoctorDto(int id, String licenseNumber, String fullName, String phone, String specialtyName) {
        this.id = id;
        this.licenseNumber = licenseNumber;
        this.fullName = fullName;
        this.phone = phone;
        this.specialtyName = specialtyName;
    }

    public int getId() {
		 return id;
		 }
    public void setId(int  id) { 
		this.id = id; 
	}
    public String getLicenseNumber() {
		 return licenseNumber; 
		}

    public void setLicenseNumber(String licenseNumber) {
		 this.licenseNumber = licenseNumber;
		 }
    public String getFullName() {
		 return fullName;
		 }

    public void setFullName(String fullName) {
		 this.fullName = fullName; }
    public String getPhone() {
		 return phone; 
		}
    public void setPhone(String phone) {
		 this.phone = phone; 
		}

    public String getSpecialtyName() {
		return specialtyName; 
	}

    public void setSpecialtyName(String specialtyName) { 
		this.specialtyName = specialtyName; 
	}
}