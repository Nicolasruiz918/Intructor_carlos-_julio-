package com.sena.crudbasic.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

@Entity
@Table(name = "admission")
public class Admission {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_admission")
    private int id;

    @Column(name = "admission_date")
    private LocalDateTime admissionDate = LocalDateTime.now();

    @Column(name = "discharge_date")
    private LocalDateTime dischargeDate;

    @ManyToOne
    @JoinColumn(name = "id_patient")
    private Patient patient;

    @ManyToOne
    @JoinColumn(name = "id_room")
    private HospitalRoom room;

    public Admission() {
    }

    public int  getId() { 
        return id;
     }

    public void setId( int  id) { 
        this.id = id;
     }

    public LocalDateTime getAdmissionDate() {
         return admissionDate;
         }

    public void setAdmissionDate(LocalDateTime admissionDate) {
         this.admissionDate = admissionDate;
         }

    public LocalDateTime getDischargeDate() {
         return dischargeDate;
         }
    public void setDischargeDate(LocalDateTime dischargeDate) {
         this.dischargeDate = dischargeDate;
         }

    public Patient getPatient() {
         return patient;
         }

         public void setPatient(Patient patient) {
             this.patient = patient;
             }

    public HospitalRoom getRoom() {
         return room;
         }

    public void setRoom(HospitalRoom room) {
         this.room = room;
         }
}